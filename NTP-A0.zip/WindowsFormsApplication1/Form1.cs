﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        List<int> sayilar = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            groupBox2.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sayilar.Add(int.Parse(textBox1.Text));
            }
            catch (FormatException)
            {
                MessageBox.Show("Hatalı veri girişi!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Clear();
                if (textBox2.Text.Length > 0)
                    listBox1.Items.Add(sayilar[int.Parse(textBox2.Text)]);
                else
                    foreach (int item in sayilar)
                    {
                        listBox1.Items.Add(item);
                    }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Belirttiğiniz sayı sayılar dizesinde bulunmuyor! Index en fazla " + sayilar.Count + " olabilir");
            }
        }


    }
}
