﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApplication1
{

    class Hesapla
    {
        public void TekCift(int baslangic, int bitis, int artis = 1)
        {
            for (int i = baslangic; i < bitis; i+=artis)
            {
                Console.WriteLine(i);
            }
        }
        //public List<int> sayilar = new List<int>();
        //private void FromTo(int f, int t, int division, int left)
        //{
        //    for (int i = f; i < t && i < sayilar.Count; i++)
        //    {
        //        if (sayilar[i]%division == left)
        //            Console.WriteLine(sayilar[i]);
        //    }
        //}
        //public void Sirala()
        //{
        //    sayilar = sayilar.OrderBy(a => a).ToList<int>();
        //}
        //public void TekSayilar(int f, int t)
        //{
        //    FromTo(f, t, 2, 1 );
        //}
        //public void CiftSayilar(int f, int t)
        //{
        //    FromTo(f, t, 2, 0 );
        //}
    }
}
