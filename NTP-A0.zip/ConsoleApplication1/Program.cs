﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Hesapla hesapla = new Hesapla();
            Console.Write("Sayı giriniz: ");
            int bitis = int.Parse(Console.ReadLine());
            bool tek = bitis % 2 != 0;
            hesapla.TekCift(tek ? 1 : 0, bitis, 2);
            //Hesapla hesapla = new Hesapla();
            //hesapla.sayilar.Add(51);
            //hesapla.sayilar.Add(96);
            //hesapla.sayilar.Add(66);
            //hesapla.sayilar.Add(8);
            //hesapla.sayilar.Add(16);
            //hesapla.sayilar.Add(12);
            //hesapla.sayilar.Add(6);
            //hesapla.sayilar.Add(99995);
            //hesapla.sayilar.Add(99996);
            //hesapla.sayilar.Add(56);
            //hesapla.sayilar.Add(17);
            //hesapla.sayilar.Add(26);
            //hesapla.Sirala();
            //Console.WriteLine("--Çift Sayılar:");
            //hesapla.CiftSayilar(0, 999);
            //Console.WriteLine("\n--Tek Sayılar:");
            //hesapla.TekSayilar(0, 999);
            Console.Read();
        }
    }
}
