﻿namespace _3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.cmbSinif2 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSinifEkle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbSinif1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOkulNo = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.cbOkulNo = new System.Windows.Forms.CheckBox();
            this.cbAd = new System.Windows.Forms.CheckBox();
            this.cbSoyad = new System.Windows.Forms.CheckBox();
            this.btnGoster = new System.Windows.Forms.Button();
            this.btnOgrenciEkle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(505, 49);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(139, 186);
            this.listBox1.TabIndex = 0;
            // 
            // cmbSinif2
            // 
            this.cmbSinif2.FormattingEnabled = true;
            this.cmbSinif2.Location = new System.Drawing.Point(380, 39);
            this.cmbSinif2.Name = "cmbSinif2";
            this.cmbSinif2.Size = new System.Drawing.Size(79, 21);
            this.cmbSinif2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(35, 36);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // btnSinifEkle
            // 
            this.btnSinifEkle.Location = new System.Drawing.Point(35, 80);
            this.btnSinifEkle.Name = "btnSinifEkle";
            this.btnSinifEkle.Size = new System.Drawing.Size(100, 31);
            this.btnSinifEkle.TabIndex = 3;
            this.btnSinifEkle.Text = "Ekle";
            this.btnSinifEkle.UseVisualStyleBackColor = true;
            this.btnSinifEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(342, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Sınıfı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(196, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Sınıfı:";
            // 
            // cmbSinif1
            // 
            this.cmbSinif1.FormattingEnabled = true;
            this.cmbSinif1.Location = new System.Drawing.Point(243, 111);
            this.cmbSinif1.Name = "cmbSinif1";
            this.cmbSinif1.Size = new System.Drawing.Size(79, 21);
            this.cmbSinif1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(179, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Okul No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ad:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(188, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Soyad:";
            // 
            // txtOkulNo
            // 
            this.txtOkulNo.Location = new System.Drawing.Point(243, 39);
            this.txtOkulNo.Name = "txtOkulNo";
            this.txtOkulNo.Size = new System.Drawing.Size(79, 20);
            this.txtOkulNo.TabIndex = 2;
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(243, 61);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(79, 20);
            this.txtAd.TabIndex = 2;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(243, 86);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(79, 20);
            this.txtSoyad.TabIndex = 2;
            // 
            // cbOkulNo
            // 
            this.cbOkulNo.AutoSize = true;
            this.cbOkulNo.Location = new System.Drawing.Point(345, 84);
            this.cbOkulNo.Name = "cbOkulNo";
            this.cbOkulNo.Size = new System.Drawing.Size(65, 17);
            this.cbOkulNo.TabIndex = 10;
            this.cbOkulNo.Text = "Okul No";
            this.cbOkulNo.UseVisualStyleBackColor = true;
            // 
            // cbAd
            // 
            this.cbAd.AutoSize = true;
            this.cbAd.Location = new System.Drawing.Point(345, 107);
            this.cbAd.Name = "cbAd";
            this.cbAd.Size = new System.Drawing.Size(39, 17);
            this.cbAd.TabIndex = 11;
            this.cbAd.Text = "Ad";
            this.cbAd.UseVisualStyleBackColor = true;
            // 
            // cbSoyad
            // 
            this.cbSoyad.AutoSize = true;
            this.cbSoyad.Location = new System.Drawing.Point(345, 130);
            this.cbSoyad.Name = "cbSoyad";
            this.cbSoyad.Size = new System.Drawing.Size(56, 17);
            this.cbSoyad.TabIndex = 12;
            this.cbSoyad.Text = "Soyad";
            this.cbSoyad.UseVisualStyleBackColor = true;
            // 
            // btnGoster
            // 
            this.btnGoster.Location = new System.Drawing.Point(345, 167);
            this.btnGoster.Name = "btnGoster";
            this.btnGoster.Size = new System.Drawing.Size(114, 31);
            this.btnGoster.TabIndex = 3;
            this.btnGoster.Text = "Göster";
            this.btnGoster.UseVisualStyleBackColor = true;
            this.btnGoster.Click += new System.EventHandler(this.btnGoster_Click);
            // 
            // btnOgrenciEkle
            // 
            this.btnOgrenciEkle.Location = new System.Drawing.Point(222, 167);
            this.btnOgrenciEkle.Name = "btnOgrenciEkle";
            this.btnOgrenciEkle.Size = new System.Drawing.Size(100, 31);
            this.btnOgrenciEkle.TabIndex = 3;
            this.btnOgrenciEkle.Text = "Ekle";
            this.btnOgrenciEkle.UseVisualStyleBackColor = true;
            this.btnOgrenciEkle.Click += new System.EventHandler(this.btnOgrenciEkle_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 262);
            this.Controls.Add(this.cbSoyad);
            this.Controls.Add(this.cbAd);
            this.Controls.Add(this.cbOkulNo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbSinif1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnGoster);
            this.Controls.Add(this.btnOgrenciEkle);
            this.Controls.Add(this.btnSinifEkle);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.txtOkulNo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.cmbSinif2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Ana Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ComboBox cmbSinif2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnSinifEkle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbSinif1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOkulNo;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.CheckBox cbOkulNo;
        private System.Windows.Forms.CheckBox cbAd;
        private System.Windows.Forms.CheckBox cbSoyad;
        private System.Windows.Forms.Button btnGoster;
        private System.Windows.Forms.Button btnOgrenciEkle;
    }
}

