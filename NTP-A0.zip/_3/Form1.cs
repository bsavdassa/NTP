﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3
{
    public partial class Form1 : Form
    {
        Dictionary<string, List<Ogrenci>> ogrenciler = new Dictionary<string, List<Ogrenci>>() { };
        ComboBox[] siniflar;
        public Form1()
        {
            InitializeComponent();
            siniflar = new ComboBox[] { cmbSinif2, cmbSinif1 };
        }
        private void comboBoxEkle(string metin)
        {
            foreach (ComboBox item in siniflar)
            {
                item.Items.Add(metin);
            }
        }
        private void btnEkle_Click(object sender, EventArgs e)
        {
            comboBoxEkle(textBox1.Text);
        }

        private void btnOgrenciEkle_Click(object sender, EventArgs e)
        {
            string key = cmbSinif1.SelectedItem.ToString();
            if (!ogrenciler.ContainsKey(key))
                ogrenciler[key] = new List<Ogrenci>() { };
            ogrenciler[key].Add(new Ogrenci() { ad = txtAd.Text, soyad = txtSoyad.Text, okulNo = txtOkulNo.Text });
        }

        private void btnGoster_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (Ogrenci ogrenci in ogrenciler[(string)cmbSinif2.SelectedItem])
            {
                string yazdir = "";
                if (cbOkulNo.Checked){
                    yazdir += ogrenci.okulNo + " ";
                }
                if (cbAd.Checked)
                {
                    yazdir += ogrenci.ad + " ";
                }
                if (cbSoyad.Checked)
                {
                    yazdir += ogrenci.soyad + " ";
                }
                listBox1.Items.Add(yazdir);
            }
        }


    }
}
